package ffdc;

public class IDs {

	 private String name;  // �ܺο��� Name ���� �������� ���ϰ� private ���� ����
     private String pass;
     private int position;	// position1 : Moderator, position2 : team member
     
//     public IDs(String name, String pass){
//    	 this.name = name;
//		 this.pass =pass;
//		 this.position = null;
//     }
     
	 public IDs(String name, String pass,int position) {
		 this.name = name;
		 this.pass =pass;
		 this.position = position;
	 }
   
	 public String getName() {
		 return name;
     }

	 public String getPass() {
		  return pass;
	 }
	 
	 public int getPosition(){
		 return position;
	 }
}



