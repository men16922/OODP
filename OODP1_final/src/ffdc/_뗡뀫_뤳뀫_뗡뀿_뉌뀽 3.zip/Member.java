package ffdc;
import javax.swing.JTextArea;

public class Member implements User{
	
	private int memberIndex;
	
	public void ViewProfile(JTextArea testArea, JTextArea testArea2){
		//�α��� �ε����� ��ġ�ϴ� ���� ���
		setMemberIndex(0);
		
		for(Iterator2 it = Frame.IDlist.iterator(); it.hasNext(); ) {
			IDs IDs4 = (IDs) it.next();
			setMemberIndex(getMemberIndex()+1);
			
			if(getMemberIndex()-1 == P_One.loginIndex){
	    		testArea.append("ID: " + IDs4.getName());
	    		testArea.append(" PW: " + IDs4.getPass() +"\n");
			}
    	}
		
		setMemberIndex(0);
		for(Iterator2 it = Frame.Infolist.iterator();it.hasNext();) {
			PersonInfo info = (PersonInfo) it.next();
			setMemberIndex(getMemberIndex()+1);
			
			if(getMemberIndex()-1 == P_One.loginIndex){
			 	testArea2.append(" Name: " + info.getname());
			 	testArea2.append(" StNr: " + info.getStnr());
			 	testArea2.append(" Birth: " + info.getbirth());
			 	testArea2.append(" phone: " + info.getphone() + "\n");
			}
		}
	}
	
	public void setMemberIndex(int memberIndex){
		this.memberIndex = memberIndex; 
	}
	
	public int getMemberIndex(){
		return memberIndex;
	}
}
