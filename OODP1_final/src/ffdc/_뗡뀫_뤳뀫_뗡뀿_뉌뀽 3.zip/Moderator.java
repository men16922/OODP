package ffdc;
import javax.swing.JTextArea;

public class Moderator implements User {
	
	public void ViewProfile(JTextArea testArea, JTextArea testArea2){
		for(Iterator2 it = Frame.IDlist.iterator();it.hasNext();) {
    		IDs IDs4 = (IDs) it.next();
    		testArea.append("ID: " + IDs4.getName());
    		testArea.append(" PW: " + IDs4.getPass() +"\n");
    	}
		for(Iterator2 it = Frame.Infolist.iterator();it.hasNext();) {
			PersonInfo info = (PersonInfo) it.next();
		 	testArea2.append(" Name: " + info.getname());
		 	testArea2.append(" StNr: " + info.getStnr());
		 	testArea2.append(" Birth: " + info.getbirth());
		 	testArea2.append(" phone: " + info.getphone() + "\n");
		}
	}
}
