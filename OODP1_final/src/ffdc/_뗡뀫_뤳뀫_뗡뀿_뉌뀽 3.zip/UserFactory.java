package ffdc;

public class UserFactory implements AbstractUserFactory{
		
	public static User CreateUser(int type){
		if(type == 1)
			return new Moderator();
		
		else if(type == 2)
			return new Member();
		
		else if(type == 0)
			return new NullUser();
		
		else return null;
	}
}
