package ffdc;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import ffdc.Frame;

public class P_Three extends JPanel {
	private Buttonlist Buttonlist= new Buttonlist(2);
	private Buttonlist Buttonlist2= new Buttonlist(3);
	
	private JButton[] jbtn = new JButton[4];
	private JLabel[] jlb = new JLabel[6];
	private JTextField[] Jtxt = new JTextField[6];
    private JButton btn1,btn2,btn3,btn4,btn5,btn6;
    private Frame F;
    private Font f1,f2,f3;
	private JDialog jDialog = new JDialog(F, "Team date Input");
	private JDialog jDialog2 = new JDialog(F, "Team date Input");
	
	
	
	
    
   
    
	String number;
	String[] n1= new String[Frame.max];
	teamdistinct team= teamdistinct.getinstance();
	int number2;
	int year,month,day;

	
    public P_Three(Frame f) {	 
    	
    	int i=Frame.zero;
        int j=Frame.zero;
    
    		Buttonlist.addButtons(new Buttons("Click"));
    		Buttonlist.addButtons(new Buttons("Exit"));
    		
    		Buttonlist2.addButtons(new Buttons("Year"));
    		Buttonlist2.addButtons(new Buttons("Month"));
    		Buttonlist2.addButtons(new Buttons("Day"));
    	    

    	
    	
       
    	f1 = new Font("���� ����", Font.PLAIN, 40);//15
		f2 = new Font("����", Font.BOLD, 50);//20
		f3 = new Font("����", Font.ITALIC, 75);//30
    	
       setBackground(Color.GRAY);
       setSize(1200,1200);//600,600
       setLayout(null);
          
       
       F = f;
       jDialog.setLayout(new GridLayout(2,2));
       jDialog.setSize(600, 600);//300,300
       
     
       for(Iterator2 it = Buttonlist2.iterator();it.hasNext();) {
    	   Buttons Buttons = (Buttons) it.next();
         	jDialog.add(jlb[j]= new JLabel(Buttons.getName()));
         	jlb[j].setFont(f1);
         	Jtxt[j]=new JTextField("");
         	Jtxt[j].setFont(f1);
         	jDialog.add(Jtxt[j]);
         	j++;
       }
     
       for(Iterator2 it = Buttonlist.iterator();it.hasNext();) {
           
      		Buttons Buttons = (Buttons) it.next();
          	jDialog.add(jbtn[i]= new JButton(Buttons.getName()));
          	jbtn[i].setFont(f1);
          	i++;
          	
          }
       
       jDialog2.setLayout(new GridLayout(2,2));
       jDialog2.setSize(600, 600);//300,300
       
     
       for(Iterator2 it = Buttonlist2.iterator();it.hasNext();) {
    	   Buttons Buttons = (Buttons) it.next();
         	jDialog2.add(jlb[j]= new JLabel(Buttons.getName()));
         	jlb[j].setFont(f1);
         	Jtxt[j]=new JTextField("");
         	Jtxt[j].setFont(f1);
         	jDialog2.add(Jtxt[j]);
         	j++;
       }     
        	
   	for(Iterator2 it2 = Buttonlist.iterator();it2.hasNext();) {
           
   		Buttons Buttons = (Buttons) it2.next();
       	jDialog2.add(jbtn[i]= new JButton(Buttons.getName()));
       	jbtn[i].setFont(f1);
       	i++;
       	
       } 
       jDialog.setLocation(400,300);//800,600
       jDialog2.setLocation(400,300);//800,600
       jbtn[0].addActionListener(new ActionListener() {
      	   public void actionPerformed(ActionEvent arg0) {
      		
      		 number=Jtxt[0].getText();
    		   year=Integer.parseInt(number);
    		 
    		   Integer.parseInt(number);
    		   number=Jtxt[1].getText();
    		   number2=Integer.parseInt(number);
    		
    		   if(number2>0 && number2<13){
    			   month=number2;}
    		   else{
    			   JOptionPane.showMessageDialog(null, "Failed" );
    		   }
    		   number=Jtxt[2].getText();
    		   number2=Integer.parseInt(number);
    		   if(number2>0 && number2<=31){
         			day=number2;
         			   			
   		      
   		      	
      		   }
    		  number="x";
    		   
      		   Dates tempobject = (new Dates(year,month,day));
     
      		 int checkdate=Frame.zero;
			for(Iterator2 it = Frame.Datelist.iterator();it.hasNext();)
			{
				Dates temp =(Dates) it.next();

		
				
				
				if(tempobject.getDates()==temp.getDates() && tempobject.getMonth()==temp.getMonth() && tempobject.getDay()==temp.getDay())
				{
					checkdate=1;
					 JOptionPane.showMessageDialog(null, "No �ߺ�");
					
					 					break;
				}
				
      	   }
			if(checkdate==0)
			{
				Frame.Datelist.addDates(new Dates(year,month,day));
			
			     team.setCheckarray(number);
			     team.CheckCheckarray(team.getCheck1());
			  
				JOptionPane.showMessageDialog(null, tempobject.getDates()+ "-" + tempobject.getMonth()+ "-" + tempobject.getDay());	
				
             
               team.setCheck1(team.getCheck1()+1);
               
			}
       
		
			
      	   }  
      	   });     	   
      	   
       jbtn[1].addActionListener(new ActionListener() {
      	   public void actionPerformed(ActionEvent arg0) {
      		jDialog.dispose();
      		
           }
          });
       
       jbtn[2].addActionListener(new ActionListener() {
     	   public void actionPerformed(ActionEvent arg0) {
     		  
     		  number=Jtxt[3].getText();
     		  number2=Integer.parseInt(number);
     		  year=number2;
     		  number=Jtxt[4].getText();
     		  number2=Integer.parseInt(number);
     		  if(number2>0 && number2<13) {
       			   month=number2;
       		   }
       		   else{
       			   JOptionPane.showMessageDialog(null, "Failed" );
       		   }
       			number=Jtxt[5].getText();
       		   	number2=Integer.parseInt(number);
         		if(number2>0 && number2<=31){
         			day=number2;
         			number="x";
         			Dates tempobject = (new Dates(year,month,day));
         			for(Iterator2 it = Frame.Datelist.iterator();it.hasNext();)
           			{
           				
           				Dates temp =(Dates) it.next();
           				
               			if(tempobject.getDates()==temp.getDates() && tempobject.getMonth()==temp.getMonth() && tempobject.getDay()==temp.getDay())
               			{
               				team.setCheckarray(number);
              			     team.CheckCheckarray(team.getCheck2());
               			}
               			
               			team.setCheck2(team.getCheck2()+1);
           			}
         			JOptionPane.showMessageDialog(null, tempobject.getDates()+ "-" + tempobject.getMonth()+ "-" + tempobject.getDay());
               			
               		team.setCheck2(0);
           		  }
         		else{
    			   JOptionPane.showMessageDialog(null, "Failed" );
    		   }
         		                 	   }
	  });
       jbtn[3].addActionListener(new ActionListener() {
      	   public void actionPerformed(ActionEvent arg0) {
      	
      		jDialog2.dispose();
           }
          });
       
       btn1 = new JButton("1. Attendance Checklist");
       btn1.addActionListener(new ActionListener() {
    	   public void actionPerformed(ActionEvent arg0) {
    		   int i=0;
    		   for(Iterator2 it = Frame.Datelist.iterator();it.hasNext();)  {
    			   Dates temp =(Dates) it.next();
       			   team.setCheck3(i); 
    			   n1[i] = temp.getDates()+ "-" + temp.getMonth()+ "-" + temp.getDay()+ "-"+team.getCheckarray3();
    			   i++;
    		   }
    	
    		   JOptionPane.showMessageDialog(null, n1);
            }
        });
        btn1.setBounds(20, 35, 600, 60);//(20, 35, 113, 23);
        btn1.setFont(f1);
        add(btn1);
        
        btn2 = new JButton("2. Create Attendance Check");
        btn2.addActionListener(new ActionListener() {
             public void actionPerformed(ActionEvent arg0) {
            	 jDialog.setVisible(true);
             }
         });
         btn2.setBounds(20, 115, 600, 60);//(20, 70, 113, 23);
         btn2.setFont(f1);
         add(btn2);
        
         btn3 = new JButton("3. Cancel Attendance Check");
         btn3.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent arg0) {
            	  jDialog2.setVisible(true);
            	              	  
              }
         });
         btn3.setBounds(20, 195, 600, 60);//(20, 105, 113, 23);
         btn3.setFont(f1);
         add(btn3);
         btn4 = new JButton("4. Create Event");
         btn4.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent arg0) {
        		 F.getCardLayout().show(F.getContentPane(), "Two");
        	 }
         });
         btn4.setBounds(20, 275, 600, 60);//(20, 140, 113, 23);
         btn4.setFont(f1);
         add(btn4);
         
         btn5 = new JButton("5. Delete Event");
         btn5.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent arg0) {
            	  F.getCardLayout().show(F.getContentPane(), "Two");        	
        	 }
         });
          
         btn5.setBounds(20, 355, 600, 60);//(20, 175, 113, 23);
         btn5.setFont(f1);
         add(btn5);
            
         btn6 = new JButton("6. Back to Main menu");
         btn6.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent arg0) {
        		 F.getCardLayout().show(F.getContentPane(), "Two");
        	 }
         });
         
         btn6.setBounds(20, 435, 600,60);//(20, 210, 113, 23);
         btn6.setFont(f1);
         add(btn6);
 
         setVisible(true);
    }
}
    


