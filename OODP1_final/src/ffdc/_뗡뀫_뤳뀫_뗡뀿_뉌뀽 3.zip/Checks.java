package ffdc;

public class Checks {
private String check;

public Checks(String check) {
	this.check=check;
	
	
}
public String getCheck() {
	return check;
}
}
