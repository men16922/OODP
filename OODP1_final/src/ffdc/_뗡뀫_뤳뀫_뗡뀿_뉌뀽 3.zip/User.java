package ffdc;
import javax.swing.JTextArea;

public interface User {
	public void ViewProfile(JTextArea testArea, JTextArea testArea2);
}
