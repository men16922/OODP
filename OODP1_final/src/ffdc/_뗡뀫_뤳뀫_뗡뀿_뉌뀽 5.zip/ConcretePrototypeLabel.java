package ffdc;

import java.awt.Font;


//import Prototype.ConcretePrototypeLabel;

public class ConcretePrototypeLabel implements Prototype, Cloneable{
	private Object Font;
	private Font f1, f2, f3;
	
    
    public ConcretePrototypeLabel(Font f){
        	this.Font = f; 
    }
       
    
    public void setFont(Font f) {
            this.Font = f;
    }
    
    public ConcretePrototypeLabel clone() throws CloneNotSupportedException {
        return (ConcretePrototypeLabel) super.clone();
    }
 
}
     


   