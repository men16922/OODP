package ffdc;

public class Dates {
	
	 private int year;
     private int month;
     private int day;
     
 
     
     public Dates(int year, int month, int day) {

   	 this.year= year;
   	 this.month= month;
   	 this.day =day;
   	 
   	 }
      

   	 public int getDates() {

   	  return year;   	   	 
        
   	 }

   	 public int getMonth() {

   		  return month;
   	     
   		 }
   	public int getDay() {

 		  return day;
 	     
 		 }
  

   

}
