package ffdc;

import javax.swing.JTextArea;

public interface TeamMeeting{
	public void printActivity(JTextArea memoArea);
}