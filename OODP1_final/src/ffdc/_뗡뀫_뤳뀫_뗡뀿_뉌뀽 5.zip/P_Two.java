package ffdc;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
import javax.swing.*;


public class P_Two extends JPanel {

    private JButton btn1,btn2,btn3,btn4,btn5,btn6;
	private Font f1, f2, f3;
	private Buttonlist Buttonlist= new Buttonlist(2);
	private Buttonlist Buttonlist2= new Buttonlist(3);
    private Frame F;
    private JDialog jDialog = new JDialog(F, "Attendance date Input");
	private JDialog jDialog2 = new JDialog(F, "Team Profile");
	
	private JButton[] jbtn = new JButton[3];
	public static int logincheck=Frame.zero;
    private JButton jButton = new JButton("Clear");
    private JLabel[] jlb = new JLabel[3];
	private JTextField[] Jtxt = new JTextField[3];
	Iterator2 it = Frame.IDlist.iterator();
	teamdistinct team= teamdistinct.getinstance();
	String number;
	
	int number2;
	int year,month,day;
	
	LoginInformation loginInformation = LoginInformation.getInstance();
	
    public P_Two(Frame f) {
    	Buttonlist.addButtons(new Buttons("Click"));
		Buttonlist.addButtons(new Buttons("Exit"));
		
    	Buttonlist2.addButtons(new Buttons("Year"));
		Buttonlist2.addButtons(new Buttons("Month"));
		Buttonlist2.addButtons(new Buttons("Day"));
    	f1 = new Font("���� ����", Font.PLAIN, 40);//15
		f2 = new Font("����", Font.BOLD, 50);//20
		f3 = new Font("����", Font.ITALIC, 75);//30

		setBackground(Color.GRAY);
        setSize(1200,1200);//600,600
        setLayout(null);
        jDialog.setLayout(new GridLayout(2,2));
        F = f;
        
        jDialog.setSize(600, 600);//300,300
        int i=Frame.zero;
        int j=Frame.zero;
        
        for(Iterator2 it = Buttonlist2.iterator();it.hasNext();) {
     	   Buttons Buttons = (Buttons) it.next();
          	jDialog.add(jlb[j]= new JLabel(Buttons.getName()));
          	jlb[j].setFont(f1);
          	Jtxt[j]=new JTextField("");
          	Jtxt[j].setFont(f1);
          	jDialog.add(Jtxt[j]);
          	j++;
        }
        for(Iterator2 it = Buttonlist.iterator();it.hasNext();) {
            
      		Buttons Buttons = (Buttons) it.next();
          	jDialog.add(jbtn[i]= new JButton(Buttons.getName()));
          	jbtn[i].setFont(f1);
          	i++;
          	
          }
       
        
        jDialog.setLocation(400,300);//800,600
        
        jDialog2.setSize(600, 600);//300,300
        jDialog2.setLocation(400,300);//800,600
        
       jDialog2.setLayout(null);
        jDialog2.add(jButton);
        JTextArea testArea =new JTextArea();
        JTextArea testArea2 =new JTextArea();
        JScrollPane scrollPane = new JScrollPane(testArea);
        JScrollPane scrollPane2 = new JScrollPane(testArea2);
       
       // testArea.setBounds(50,50,500,400);
        scrollPane.setBounds(0,0,300,450);
        scrollPane2.setBounds(300,0,300,450);
        jButton.setBounds(50, 450, 100, 100);
        testArea.setEditable(false);
        testArea2.setEditable(false);
       jDialog2.add(scrollPane);
       jDialog2.add(scrollPane2);
        
       jButton.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent arg0) {
           	testArea.setText(""); 	
           	testArea2.setText(""); 
            }
        });

   
        //jDialog2.add(testArea);
        
        jbtn[0].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
      		   number=Jtxt[0].getText();
      		   number2=Integer.parseInt(number);
      		   year=number2;
      		   number=Jtxt[1].getText();
    		   number2=Integer.parseInt(number);
    		   
    		   if(number2 > 0 && number2 <13){
    			   month=number2;
    		   }
    		   else{
    			   JOptionPane.showMessageDialog(null, "Failed" );
    		   }
    		   
    		   number=Jtxt[2].getText();
      		   number2=Integer.parseInt(number);
      		   if(number2 > 0 && number2<=31){
      			   day=number2;
      			   number="o";
      			   Dates tempobject = (new Dates(year,month,day));
      			   
      			   for(Iterator2 it = Frame.Datelist.iterator();it.hasNext();){
      				   Dates temp =(Dates) it.next();
      				   if(tempobject.getDates()==temp.getDates() && tempobject.getMonth()==temp.getMonth() && tempobject.getDay()==temp.getDay()){
      					   team.setCheckarray(number);
      					   team.CheckCheckarray(team.getCheck2());
      				   }
      				   team.setCheck2(team.getCheck2()+1);
      			   }
      			   
      			   JOptionPane.showMessageDialog(null, tempobject.getDates()+ "-" + tempobject.getMonth()+ "-" + tempobject.getDay());
          			team.setCheck2(0);
      		  }      			
      		   else{
      			   JOptionPane.showMessageDialog(null, "Failed" );
      		   }
        	}
        });
        
        jbtn[1].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
      		jDialog.dispose();
            }
        });

       btn1 = new JButton("1. View Profile");
       btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	jDialog2.setVisible(true);
            	User user = UserFactory.CreateUser(loginInformation.getPosition());//��� position ��ġ��
            	user.ViewProfile(testArea, testArea2);
            }
       });
       btn1.setBounds(20, 35, 600, 60);//(20, 35, 113, 23);
       btn1.setFont(f1);
       add(btn1);

       btn2 = new JButton("2. Attendace Check");
       btn2.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent arg0) {
          	 jDialog.setVisible(true); 	 
           }
       });
        
       btn2.setBounds(20, 115, 600, 60);//(20, 70, 113, 23);
       btn2.setFont(f1);
       add(btn2);
       
       btn3 = new JButton("3. Create Event");
       btn3.addActionListener(new ActionListener() {
             public void actionPerformed(ActionEvent arg0) {
             	F.getCardLayout().show(F.getContentPane(), "Three");     	
              }
          });
       btn3.setBounds(20, 195, 600, 60);//20, 105, 113, 23);
       btn3.setFont(f1);
       add(btn3);
          
       btn4 = new JButton("4. View Calendar");
       btn4.addActionListener(new ActionListener() {
    	   public void actionPerformed(ActionEvent arg0) {
       Calendar calendar = Calendar.getInstance();
    		   
    		   int year = calendar.get(Calendar.YEAR);
    		   int month = calendar.get((Calendar.MONTH)+1);
    		   
    		   MemoCalendar cal = new MemoCalendar();
           }
       });
       btn4.setBounds(20, 275, 600, 60);//(20, 140, 113, 23);
       btn4.setFont(f1);
       add(btn4);
           
       btn5 = new JButton("5. LogOut");
       btn5.addActionListener(new ActionListener() {
    	   public void actionPerformed(ActionEvent arg0) {
    		   F.getCardLayout().show(F.getContentPane(), "One");
    	   }
       });
       btn5.setBounds(20, 355, 600, 60);//(20, 175, 113, 23);
       btn5.setFont(f1);
       add(btn5);
            
       btn6 = new JButton("6. Team Edit");
       btn6.addActionListener(new ActionListener() {
    	   public void actionPerformed(ActionEvent arg0) {
    		  logincheck=Frame.one;
    		   F.getCardLayout().show(F.getContentPane(), "Join4");
    	   }
       });
       btn6.setBounds(20, 435, 600, 60);//(20, 210, 113, 23);
       btn6.setFont(f1);
       add(btn6);
 
       setVisible(true);
    }
}
    

