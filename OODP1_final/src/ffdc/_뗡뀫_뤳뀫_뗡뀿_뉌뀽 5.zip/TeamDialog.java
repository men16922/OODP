package ffdc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class TeamDialog extends JFrame{
	
	public TeamDialog(JTextArea memoArea){
		JButton btn1,btn2,btn3,btn4,btn5,btn6;
		JPanel p = new JPanel();
				
		btn1 = new JButton("1. ������");
		btn2 = new JButton("2. 10���� ������Ʈ");
		btn3 = new JButton("3. ��ũ��Ƽ");
		btn4 = new JButton("4. BBQ");
		btn5 = new JButton("5. �� Ư��");
		btn6 = new JButton("6. ���� ����");

		ActionListener handler = new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e){
				TeamMeeting teamMeeting = new ConcreteTeamMeeting(); 

				if (e.getActionCommand().equals("1. ������"))
					teamMeeting = new ConcreteDeco1(teamMeeting);
				
				else if(e.getActionCommand().equals("2. 10���� ������Ʈ"))
					teamMeeting = new ConcreteDeco2(teamMeeting);
				
				else if(e.getActionCommand().equals("3. ��ũ��Ƽ"))
					teamMeeting = new ConcreteDeco3(teamMeeting);
				
				else if(e.getActionCommand().equals("4. BBQ"))
					teamMeeting = new ConcreteDeco4(teamMeeting);
				
				else if(e.getActionCommand().equals("5. �� Ư��"))
					teamMeeting = new ConcreteDeco5(teamMeeting);
				
				else if(e.getActionCommand().equals("6. ���� ����"))
					teamMeeting = new ConcreteDeco6(teamMeeting);
				
				teamMeeting.printActivity(memoArea);
			}
		};
		
		btn1.addActionListener(handler);
		btn2.addActionListener(handler);
		btn3.addActionListener(handler);
		btn4.addActionListener(handler);
		btn5.addActionListener(handler);
		btn6.addActionListener(handler);

		p.add(btn1);
		p.add(btn2);
		p.add(btn3);
		p.add(btn4);
		p.add(btn5);
		p.add(btn6);
	
		add(p);
		pack();
		
		setLocation(400,400);
		setVisible(true);
	}
}
