package ffdc;

import javax.swing.JTextArea;

public class NullUser implements User{
	
	public void ViewProfile(JTextArea testArea, JTextArea testArea2){
    		testArea2.append("This function is available after login.");
	}
}
