package ffdc;
import java.io.*;
import java.util.TreeSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.Iterator;
public class Read {
	
	private static int count;
	
	public static void readtext(String userText, char [] passText) {
		ArrayList<String> set =  new ArrayList<String>();
		ArrayList<String> pass= new ArrayList<String>();
		LoginInformation loginInformation = LoginInformation.getInstance();
		
		try {
			File file = new File("ID.txt");
			File file2 = new File("pass.txt");
			FileReader filereader= new FileReader(file);
			BufferedReader bufreader = new BufferedReader(filereader);
			FileReader filereader2= new FileReader(file2);
			BufferedReader bufreader2 = new BufferedReader(filereader2);
			String line="";
			String line2="";
			String pas="";
			
			for (int i = 0; i < passText.length; i++) {
			    pas += Character.toString(passText[i]);
			}
			
			while((line=bufreader.readLine()) !=null) {
 				set.add(line);
 						 					
 			}
			bufreader.close();
			while((line2=bufreader2.readLine()) !=null) {
	 			pass.add(line2);			 					
	 		}
			 
			bufreader2.close();
			Iterator<String> it=set.iterator();
			Iterator<String> Pit=pass.iterator();
			
			while(it.hasNext()) {
			   
				String n=it.next();
				String n2= Pit.next();

				if(n.equals(userText) && n2.equals(pas))
				{
					loginInformation.setLoginIndex(count-1);
					P_One.bLoginCheck=true;
				 }
			} 
		}
		catch(IOException e) {
		}
		
	}
	public static void readteam() {
		ArrayList<String> team =  new ArrayList<String>();

try {
	File file = new File("team.txt");
	
	FileReader filereader= new FileReader(file);
	BufferedReader bufreader = new BufferedReader(filereader);

	String line="";
	
	

	
	 while((line=bufreader.readLine()) !=null) {
			team.add(line);
					 					
		}
	 bufreader.close();
	
	 
	 Iterator<String> it=team.iterator();
	
	
	 while(it.hasNext()) {
		   
		 String n=it.next();
		 Joindisplay4.addlist(n);
	} 
}
	catch(IOException e) {
	}
	
	}

}
