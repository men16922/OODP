package ffdc;

import java.awt.Font;

public interface Prototype 
{
  
    public void setFont(Font f);

}//end interface Prototype