package ffdc;

import java.awt.Color;
import java.awt.Font;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class TeamModerate extends JoinFlow {
	
    private Frame F;
	private JButton btnLogin;
	private JButton btnInit;
	private JTextField userText;
	
	private static int checkid=Frame.zero;
	private Font f1, f2, f3;
	private String n;
	//-------------------
	private JButton btnref;
	private static Set<String> team =  new TreeSet<String>();
    private JList list;

	
    @Override
	void JoinFlow0(Frame f) {

		F = f;
		
		List teamlist = new List(5);
		teamlist.setBounds(240, 250, 400, 65);//(100, 210, 160, 25);
		teamlist.setFont(f1);
		add(teamlist);
		   
		   
		   
	    btnref= new JButton("Refresh");
	          btnref.setBounds(320, 350, 250, 65);//(40, 280, 100, 25);
	     btnref.setFont(f1);
	     add(btnref);
	     btnref.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {                                          
	           teamlist.removeAll();                
	           Read.readteam(); 
			}
	     });
		  btnInit = new JButton("Enter");
				btnInit.setBounds(40, 700, 250, 65);//(40, 280, 100, 25);
				btnInit.setFont(f1);
				add(btnInit);
				btnInit.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						if(P_Two.logincheck==Frame.zero) {
						if(teamlist.getSelectedIndex()==-1)
						{
							String n="���Է�";
							teamwrite.teamlist(n);
							
							JOptionPane.showMessageDialog(null, "Success");
							F.getCardLayout().show(F.getContentPane(), "Join2");
						}
						else {
								String n=teamlist.getSelectedItem();		
					teamwrite.teamlist(n);
					JOptionPane.showMessageDialog(null, "Success");
					F.getCardLayout().show(F.getContentPane(), "Join2");	
						}
						}
						
			     	if(P_Two.logincheck==Frame.one) {
			     		if(teamlist.getSelectedIndex()==-1)
						{
			     			System.out.println("�α���");
							String n="���Է�";
							teamwrite.editteam(n);
							JOptionPane.showMessageDialog(null, "Success");
							F.getCardLayout().show(F.getContentPane(), "Two");
						}
			     		else {
			     			System.out.println("�α���2");
								String n=teamlist.getSelectedItem();		
					teamwrite.editteam(n);
					JOptionPane.showMessageDialog(null, "Success");
					F.getCardLayout().show(F.getContentPane(), "Two");
			     		}
			     	} 
				}
					
				});
		}
    @Override
	void check(){}
	
    @Override
	public void addlist(String n) {
			team.add(n);
		}	

}
