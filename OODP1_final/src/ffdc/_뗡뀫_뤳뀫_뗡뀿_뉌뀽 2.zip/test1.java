package ffdc;
import java.util.Scanner;

import java.util.*;

class NotSupportedNameException extends Exception{
	 
	 public NotSupportedNameException(){
		 super("QUITQUITQUIT");
	 }
	 
	 public NotSupportedNameException(String msg){
		 super(msg);
	 }
}

public class test1 {
	
	static int current = 0;
	static Info[] info = new Info[10];
	
	public static void login(String name, String pwd) throws NotSupportedNameException{
		int i; 
		int suc = 0;
		
		System.out.println("login display");
		String Idname= name;
		String Idpwd =pwd;
	  
		for (i = 0; i < 10; i++){
			if(Idname.equals(info[i].ID) && Idpwd.equals(info[i].password))
			{
			System.out.println(Idname+" Welcome");
			System.out.println("Login success");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) { }
			OODP1 enter= new OODP1();
			clearScreen();
			enter.menuDisplay();
			enter.selectMenu();
			suc = 1;
			break;
			}
	 }
		
		if (suc == 0)
			throw new NotSupportedNameException("Login Fail");
			
	}
	
	 public static void clearScreen() {
		    for (int i = 0; i < 80; i++)
		      System.out.println("");
	 }
	 
	 public static void Input() {
		  String name; String pwd;
		  System.out.println("-----Login Display---- Enter Q if you want quit");
		  System.out.println("ID: ");
		  Scanner sc= new Scanner(System.in);
		  name=sc.nextLine();
		  if (name.equals("Q"))
		  {
			  System.exit(0);
		  }
		  System.out.println("Password: ");
		  pwd=sc.nextLine();
		  
		  try {
			  login(name,pwd); 
		  }
		  catch(NotSupportedNameException e){
			   String msg=e.getMessage(); // øπø‹ ∏ﬁΩ√¡ˆ∏¶ πÆ¿⁄ø≠∑Œ π›»Ø«—¥Ÿ.
			   System.out.println(msg);
		  }
	 }
	 
		public static void join(){
	
			  System.out.println("-----Join Display-----");
			  System.out.println("Enter ID you want.");
			  
			  System.out.println("ID: ");
			  Scanner sca= new Scanner(System.in);
			  info[current].setID(sca.nextLine());
			  System.out.println("Password: ");
			  info[current].setPW(sca.nextLine());
			  current++;
			  
			  Input();

		}

	 
}