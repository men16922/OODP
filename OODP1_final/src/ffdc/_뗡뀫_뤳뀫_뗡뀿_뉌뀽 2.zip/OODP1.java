package ffdc;
import java.util.*;
import java.util.Scanner;

public class OODP1{
	
	public static void menuDisplay(){
		System.out.println("Choose the MENU you want to run : ");
		System.out.println("");
		
		System.out.println("1. View Profile");
		System.out.println("2. Attendace Check");
		System.out.println("3. Create Event");
		System.out.println("4. View Calendar");
		System.out.println("5. LogOut\n");
		System.out.print("Your Choice : ");
	}
	
	public void selectMenu(){
		Scanner kb = new Scanner(System.in);
		int choice = kb.nextInt();
		
		switch (choice){
		case 1:
			ViewProfile();
			break;
			
		case 2:
			AttendanceCheck();
			break;
			
		case 3:
			CreateEvent();
			break;
			
		case 4: 
			ViewCalendar();
			break;
		
		case 5:
			LogOut();
			break;
			
		default:
			System.out.println("Wrong Choice");
		}
	}
	
	public static void ViewProfile(){
		System.out.println("View Profile Method");
	}
	
	public static void AttendanceCheck(){
		System.out.println("Attendance Check Method");
	}
	public static void CreateEvent(){
		System.out.println("1. Attendance Check");
		System.out.println("2. Create Attendacne Check");
		System.out.println("3. Cancel Attendance Check");
		System.out.println("4. Create Event");
		System.out.println("5. Delete Event");
	}
	public static void ViewCalendar(){
		System.out.println("View Calendar Method");
		//1. View Calendar
		//2. Post Reply
	}
	public static void LogOut(){
		System.out.println("logout completed");
		test1 goback= new test1();
		goback.Input();
	}
}