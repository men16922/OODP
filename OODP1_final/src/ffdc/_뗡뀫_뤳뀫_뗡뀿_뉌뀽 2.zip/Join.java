package ffdc;
import java.util.*;

public class Join {
	static test1 t = new test1();

	public static void VeryFirst(){
		System.out.println("");
		System.out.println("1. Join");
		System.out.println("2. Log In");
	
		System.out.print("Select number you want : ");
		selectMenu();
	}
	
	
	public static void selectMenu(){
		Scanner kb = new Scanner(System.in);
		int choice = kb.nextInt();

		switch (choice){
		case 1:
			t.join();
			break;
			
		case 2:
			t.Input();
			break;
			
		default:
			System.out.println("Wrong Choice");
			}
		}

		public static void main(String[] args) {
			 System.out.println("Main Display");
			 VeryFirst();
		 }

}
