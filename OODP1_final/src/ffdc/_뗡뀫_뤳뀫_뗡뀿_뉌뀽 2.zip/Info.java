package ffdc;

public class Info {
	static String ID;
	static String password;
	
	public static void setID(String givenID){
		ID = givenID; 
	}
	
	public static void setPW(String givenPW){
		password = givenPW; 
	}
}
