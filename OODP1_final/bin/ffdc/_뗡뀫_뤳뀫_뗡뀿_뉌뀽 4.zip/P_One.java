package ffdc;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.*;

public class P_One extends JPanel {
	
    private Frame F;
    Iterator2 it = Frame.IDlist.iterator();
 
	private JButton btnLogin;
	private JButton btnInit;
	private JPasswordField passText;
	private JTextField userText;
	public static boolean bLoginCheck;
	private Font f1, f2, f3;
	
	public static int loginIndex=0;
	private static String position;
	private static int count;
	
	public static void main(String[] args) {
		//new LoginView();
	}

    public P_One(Frame f) {
    	
        setBackground(Color.LIGHT_GRAY);
        setSize(380, 350);
        f.setLocation(800, 450);
        setLayout(null);
      
        F = f;
       
        f1 = new Font("���� ����", Font.PLAIN, 40);//15
		f2 = new Font("����", Font.BOLD, 50);//20
		f3 = new Font("����", Font.ITALIC, 75);//30
		//im= new ImageIcon("handong.png");
		
		
		setVisible(true);
		JLabel userLabel3= new JLabel(new ImageIcon("h12.jpg"));
        userLabel3.setBounds(40, 100, 705, 380);
        add(userLabel3);
		
		JLabel userLabel2 = new JLabel("Team Management System");
		userLabel2.setBounds(40, 0, 1000, 100);//40,100,400,25
		userLabel2.setFont(f2);
		add(userLabel2);
		
		JLabel userLabel = new JLabel("User");
		userLabel.setBounds(40, 500, 200, 65);//(40, 210, 80, 25);
		userLabel.setFont(f2);
		add(userLabel);
		
		JLabel passLabel = new JLabel("Pass");
		passLabel.setBounds(40, 590, 200, 65);//(40, 240, 80, 25);
		passLabel.setFont(f2);
		add(passLabel);
		
		userText = new JTextField(20);
		userText.setBounds(190, 500, 400, 65);//(100, 210, 160, 25);
		userText.setFont(f2);
		add(userText);
		
		passText = new JPasswordField(20);
		passText.setBounds(190, 590, 400, 65);//(100, 240, 160, 25);
		passText.setFont(f2);
		add(passText);
		
                    
        btnInit = new JButton("Register");
		btnInit.setBounds(40, 700, 250, 65);//(40, 280, 100, 25);
		btnInit.setFont(f1);
		add(btnInit);
		btnInit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			
				F.getCardLayout().show(F.getContentPane(), "Join");
			}
		});
		btnLogin = new JButton("Login");
		btnLogin.setBounds(415, 700, 250, 65);//(190, 280, 100, 25);
		btnLogin.setFont(f1);
		add(btnLogin);
		btnLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				isLoginCheck();
			}
		});
	
	}
    /*public void setLoginIndex(int count){
    	P_One.loginIndex = count;
    }*/
    
    public int getIndex(){
    	return P_One.loginIndex;
    }
    
    public void setCount(){
    	this.count =0;
    }
    
    public void isLoginCheck(){
    	setCount();
    	Read.readtext(userText.getText(), passText.getPassword());
    	/*
    	
    	
    	if(userText.getText().equals("") && new String(passText.getPassword()).equals("")){//Id, password �Է¾��ص� �α��� ����, ������ view profile���Ұ�
    		setPosition("NULL");
    		JOptionPane.showMessageDialog(null, "Login Success" + loginIndex);
    		bLoginCheck = true;
		}
    		    */	
    	if(isLogin()){
    		F.getCardLayout().show(F.getContentPane(), "Two");
    	    bLoginCheck =false;
    	}					    	
    	else{
    		JOptionPane.showMessageDialog(null, "Faild");
    	}
    }
    
    public boolean isLogin() {		
		return bLoginCheck;
	}
    
    public void setPosition(String position){
    	P_One.position= position;
    }
    
    public static String getPosition(){
    	return P_One.position;
    }
    public static void logincheck() {
    	JOptionPane.showMessageDialog(null, "Login Success" + loginIndex);
    }
}