package ffdc;

public interface AbstractUserFactory {
	public static User CreateUser(String type){
		return null;
	}
}
