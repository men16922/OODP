package ffdc;

public class Info {
   public static String ID[]= new String [10];
   static String password[]= new String [10];
   static int Year[] = new int [10];
   static int Month[] = new int [10];
   static int Day[] = new int [10];
   static String Check[] = new String [10];
   static String IDs= "";
   static String Dates="";
}
