
public class Info {
	String ID;
	String password;
	
	public void setID(String givenID){
		ID = givenID; 
	}
	
	public void setPW(String givenPW){
		password = givenPW; 
	}
}
